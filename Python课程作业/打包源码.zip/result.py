"""
1.编写一个 Python 程序，判断用户输入的年份是否为闰年，规则如下：
（1）从控制台接收一个整数年份；
（2）闰年判断规则（需同时满足逻辑）：能被 4 整除但不能被 100 整除；或者能被 400 整除；
（3）使用 if 语句实现判断，输出 “XXXX 年是闰年” 或 “XXXX 年不是闰年”；
（4）无需处理非整数输入，仅需按规则判断。
"""

user = input("请输入年份：")
if int(user) %4== 0 and int(user)%100 != 0 or int(user)%400==0:
    print(f"{user}年是闰年")
else:
    print(f"{user}年不是闰年")
"""
1.编写一个 Python 程序，实现以下生活场景的功能：
（1）从键盘接收用户输入的一个整数（代表今天的气温，单位：摄氏度）；
（2）使用 if 语句根据气温给出穿衣建议，判断规则如下：
	气温 ≥ 25℃：输出 “今天天气热，建议穿短袖～”；
	气温 <25℃：输出 “今天天气不热，建议穿长袖～”；
（3）要求代码有清晰的输入提示，能正确接收整数输入并输出对应建议。
"""

user = input("请输入今天的气温，单位：摄氏度:")
if int(user>=25):
    print("今天天气热，建议穿短袖～")
else :
    print("“今天天气不热，建议穿长袖～”")
"""
1.编写一个Python程序，实现以下功能：
（1）从控制台接收用户输入的一个整数（代表学生的考试分数，范围0-100）；
（2）使用if语句（可结合elif、else）根据分数判断等级：
- 90分及以上：输出“优秀”；
- 80-89分：输出“良好”；1
- 70-79分：输出“中等”；
- 60-69分：输出“及格”；
- 0-59分：输出“不及格”；
- 若输入的分数超出0-100范围，输出“输入的分数无效，请输入0-100之间的整数”。
（3）要求代码具备基本的输入合法性判断（仅需判断整数范围，无需处理非数字输入）。
"""

user = input("请输入考试分数(0-100):")
score = int(user)

if score>100:
    print("输入的分数无效，请输入0-100之间的整数")
elif score>=90:
    print("优秀")
elif score>=80:
    print("良好")
elif score>=70:
    print("中等")
elif score>=60:
    print("及格")
elif score>=0:
    print("不及格")
else:
    print("输入的分数无效，请输入0-100之间的整数")
"""
2.编写一个 Python 程序，实现以下功能：
（1）接收用户输入的一个 1-10 之间的整数 n（无需处理异常输入）；
（2）利用 for 循环输出 n 行 “*”，第一行 1 个，第二行 2 个，……，第 n 行 n 个（每行的连续输出）。
"""

user = input("请输入一个1-10的整数:")
for i in range(int(user)):
    print((i+1)*"*")
"""
2.编写一个 Python 程序，实现以下功能：
（1）利用 for 循环遍历 1 到 10（包含 10）的所有整数；
（2）逐个输出这些整数，要求每个数字占一行，且有清晰的输出提示（如“当前数字：1”）。
"""

for i in range(1,11):
    print(f"当前数字：{i}")
"""
2.编写一个 Python 程序，实现以下生活场景功能：
（1）利用 while 循环计算从 1 开始的连续整数累加和，直到累加和大于 20 时停止；
（2）输出最终的累加和，以及停止时加到了哪个数字（如 “累加和大于 20 时停止，最终和为：21，加到了数字：6”）。
"""

i,s = 0 , 0
while s <=20 :
    i+=1
    s+=i
else:
    print(f"累加和大于 20 时停止，最终和为：{s}，加到了数字：{i}")
"""
3.编写一个 Python 程序，实现以下功能：
学号是学生的专属标识，不同位数字通常有不同含义（如入学年份、专业、班级、序号等）。请编写 Python 程序，实现以下基于学号字符串的操作：
接收用户输入的自己的学号（假设学号为 10 位数字字符串，如 “2024050123”，无需处理非 10 位 / 非数字输入）；
使用字符串函数完成以下操作并输出结果：
（1）输出学号的字符串长度，验证是否为 10 位；
（2）提取学号的前 4 位（代表入学年份），并输出；
（3）提取学号的最后 2 位（代表班级内序号），并输出；
（4）检测学号中数字 “2” 出现的次数，并输出（如“你的学号中数字 2 出现的次数：1”）。
"""

def count2(user):
    c2=0
    for i in user:
        if i == "2":
            c2+=1
    return c2

user = input("请输入学号：")
print(f"学号的字符串长度:{len(user)}")
print(f"前 4 位:{user[:4]}")
print(f"最后 2 位:{user[-2:]}")
print(f"你的学号中数字 2 出现的次数：{count2(user)}")
"""
4.已知两个预定义列表：course_list1 = ["Python编程", "高等数学", "英语"]course_list2 = ["计算机基础", "职业规划"]编写 Python 程序实现以下功能：
	将 course_list2 连接到 course_list1 的末尾，生成一个新的完整课程列表；
	向新列表的最后位置追加元素 “创新创业”；
	反转这个新列表，并输出最终的完整列表；
	输出新列表的总长度。
"""

course_list1 = ["Python编程", "高等数学", "英语"];course_list2 = ["计算机基础", "职业规划"]
newlist= course_list1+course_list2
newlist.append("创新创业")
newlist=newlist[::-1]
print(newlist)
print(len(newlist))
"""
4.已知预定义列表：num_list = [8, 2, 9, 5, 1, 7]
编写 Python 程序实现以下功能：
	将该列表反转，并输出反转后的完整列表；
	移除列表中索引为 3 的元素，输出移除后的列表；
	统计列表中数字 “9” 出现的次数，并输出。
"""

def c9(num):
    c9=0
    for i in num:
        if i == 9:
            c9+=1
    return c9

num_list = [8, 2, 9, 5, 1, 7]
num_list=num_list[::-1]
print(num_list)
num_list.pop(3)
print(num_list)
print(c9(num_list))
"""
4.已知预定义列表：fruit_list = ["苹果", "香蕉", "橙子", "葡萄"]，编写 Python 程序实现以下功能：
	向列表的第 2 个位置（索引为 1）插入元素 “草莓”；
	移除列表中的 “葡萄” 元素；
	向列表末尾追加元素 “芒果”；
	依次输出每一步操作后的完整列表（插入后、移除后、追加后）。
"""

fruit_list = ["苹果", "香蕉", "橙子", "葡萄"]
fruit_list.insert(1,"草莓")
print(fruit_list)
fruit_list.pop()
print(fruit_list)
fruit_list.append("芒果")
print(fruit_list)
"""
5.已知预定义字典：student_dict = {"202401":"张三","202402":"李四","202403":"王五"}
编写 Python 程序实现以下功能：
	检测字典中是否包含键 "202404"，输出检测结果（True/False）；
	将字典中键 "202402" 对应的 value 修改为 "李小四"，输出修改后的字典；
	清空字典中所有键值对，输出清空后的字典。
"""

student_dict = {"202401":"张三","202402":"李四","202403":"王五"}
print(('202404' in student_dict))
student_dict["202402"]="李小四"
print(student_dict)
student_dict={}
print(student_dict)
"""
5.已知预定义字典：score_dict = {"Python":85, "高数":78, "英语":92}编写 Python 程序实现以下功能：
	获取并输出 "Python" 对应的分数；
	向字典中增加键值对 "计算机基础":88，输出增加后的字典；
	删除字典中分数最低的键值对（本题最低为 "高数":78），输出删除后的字典；
	输出字典的键值对总数（长度）。
"""
def del_low(zd):
    lowkey=""
    lowvalue=999
    for i in zd:
        if zd[i]<=lowvalue:
            lowkey=i
            lowvalue=zd[i]
    del zd[lowkey]
    return zd

score_dict = {"Python":85, "高数":78, "英语":92}

print(score_dict["Python"])
score_dict["计算机基础"]=88
print(score_dict)
print(del_low(score_dict))
print(len(score_dict))
"""
5.已知预定义字典：building_dict = {"001":"教学楼1","002":"教学楼2","003":"教学楼3"}，编写 Python 程序实现以下功能：
（1） 遍历字典，分别输出所有的 key（键）和 value（值）（格式示例："所有键：001 002 003"、"所有值：教学楼 1 教学楼 2 教学楼 3"）；
（2） 向字典中增加键值对 "004":"教学楼 4"，并输出增加后的完整字典；
（3） 删除字典中键为 "002" 的键值对，输出删除后的完整字典。
"""

building_dict = {"001":"教学楼1","002":"教学楼2","003":"教学楼3"}
print("所有键：",end="")
_=[print(i,end=" ") for i in building_dict.keys()]
print("、所有值：",end="")
_=[print(i,end=" ") for i in building_dict.values()]
print("")
building_dict["004"]="教学楼 4"
print(building_dict)
del building_dict["002"]
print(building_dict)
"""
6.奶茶店推出消费优惠活动，编写 Python 函数实现优惠后金额计算，功能要求如下：
	定义名为calc_milk_tea_price的函数，接收一个参数：order_num（购买奶茶的杯数，正整数）；
	函数内部根据购买数量计算最终付款金额（每杯奶茶 15 元）：
	购买数量 ≥ 5 杯：总价打 7.5 折（总价 = 杯数 × 15 × 0.75）；
	3 ≤ 购买数量 < 5 杯：总价打 8.5 折（总价 = 杯数 × 15 × 0.85）；
	购买数量 < 3 杯：无折扣（总价 = 杯数 × 15）；
	函数返回计算后的最终付款金额；
	调用该函数，分别传入购买数量 2、4、6，按格式输出结果（示例：“购买 2 杯奶茶，最终付款金额：30.0 元”）。
"""

def calc_milk_tea_price(order_num:int):
    return order_num*15*(1 if order_num<3 else 0.85 if order_num<5 else 0.75)

for i in [2,4,6]:
    print(f"“购买 {i} 杯奶茶，最终付款金额：{calc_milk_tea_price(i)} 元")
"""
6.在日常生活中，我们经常需要计算商品的折后价格。
请编写一个 Python 函数，实现以下功能：
	定义一个名为calc_discount_price的函数，该函数接收一个参数：original_price（商品原价，整数 / 浮点数）；
	函数内部根据原价自动判断折扣：
	若原价 ≥ 200 元，按 8 折计算（折后价 = 原价 × 0.8）；
	若原价 < 200 元，按 9 折计算（折后价 = 原价 × 0.9）；
	函数返回计算后的折后价格；
	调用该函数，分别传入原价 150 元、原价 250 元，按指定格式输出结果（示例：“原价 150 元，折后价格为：135.0 元”）。
"""

def calc_discount_price(original_price:int|float):
    return original_price*(0.8 if original_price>=200 else 0.9)

for i in [150,250]:
    print(f"原价 {i} 元，折后价格为：{calc_discount_price(i)} 元")
"""
6.快递公司按包裹重量收取运费，编写 Python 函数实现运费计算，功能要求如下：
	定义名为calc_express_fee的函数，接收一个参数：weight（包裹重量，单位：千克，正数，整数 / 浮点数）；
	函数内部根据重量计算运费：
	重量 ≤ 1kg：运费 10 元；
	1kg < 重量 ≤ 5kg：基础运费 10 元 + 超出 1kg 部分每千克加收 2 元；
	重量 > 5kg：基础运费 18 元 + 超出 5kg 部分每千克加收 1.5 元；
	函数返回计算后的运费金额；
	调用该函数，分别传入重量 0.8、3、6，按格式输出结果（示例：“包裹重量 0.8kg，运费：10.0 元”）。
"""

import math
def calc_express_fee(weight:int|float):
    if weight<0:
        return "err"
    if weight<=1:
        m=10
    elif weight<=5:
        m=10
        m+=math.ceil(weight-1)*2
    else :
        m=18
        m+=math.ceil(weight-5)*1.5
    return m

for i in [0.8,3,6]:
    print(f"包裹重量 {i}kg，运费：{calc_express_fee(i)} 元")
"""
7.班级需要统计学生的手机话费消费情况，编写 Python 函数实现以下字典相关的统计功能：
	（1）定义名为calc_phone_fee的函数，接收一个参数：fee_dict（话费字典，格式为 {姓名：月话费金额，姓名：月话费金额...}，金额为整数，例如 {"张三":58, "李四":45, "王五":72, "赵六":65, "孙七":38}）；
	（2）函数内部完成以下操作：
		找出话费金额最高的学生姓名，返回该姓名；
		计算所有学生的平均话费（保留 1 位小数），返回该数值；
	（3）调用该函数，传入示例话费字典{"张三":58, "李四":45, "王五":72, "赵六":65, "孙七":38}，并按格式输出结果：
	输出 “话费最高的学生：王五”；
	输出 “班级平均话费：55.6 元”。
"""

def calc_phone_fee(fee_dict={}):
    maxkey=""
    maxvalue=-1
    sum=0
    for i in fee_dict:
        if fee_dict[i]>maxvalue:
            maxkey=i
            maxvalue=fee_dict[i]
        sum+= fee_dict[i]
    vag=sum/len(fee_dict)
    return maxkey,vag

maxkey,vag = calc_phone_fee({"张三":58, "李四":45, "王五":72, "赵六":65, "孙七":38})
print(f"话费最高的学生：{maxkey}")
print(f"班级平均话费：{vag}")
"""
7.统计班级学生的网课学习时长，编写 Python 函数实现以下列表相关的统计功能：
	定义名为calc_study_time的函数，接收一个参数：time_list（学生网课时长列表，元素为整数，单位：分钟，例如 [45, 60, 35, 80, 50, 75]）；
	函数内部完成以下操作：
		遍历列表，筛选出学习时长≥60 分钟的元素，生成新列表并返回；
		计算原列表中所有时长的平均值（保留 1 位小数），并返回；
	调用该函数，传入示例列表[45, 60, 35, 80, 50, 75]，并按格式输出结果：
		输出 “学习时长≥60 分钟的学生时长：[60, 80, 75]”；
		输出 “班级网课平均学习时长：57.5 分钟”。
"""

def calc_study_time(time_list=[]):
    newlist=[]
    sum=0
    for i in time_list:
        if i>=60:
            newlist.append(i)
        sum+=i
    vag=sum/len(time_list)
    return newlist,vag

newlist,vag = calc_study_time([45, 60, 35, 80, 50, 75])
print(f"学习时长≥60 分钟的学生时长：{newlist}")
print(f"班级网课平均学习时长：{vag}")
"""
7.校园社团需要统计成员的签到情况，编写 Python 函数实现以下字典相关的统计功能：
	（1）定义名为check_sign_in的函数，接收一个参数：sign_dict（签到字典，格式为 {学号：签到状态，学号：签到状态...}，状态仅为 “已签到”/“未签到”，例如 {"202401":"已签到","202402":"未签到","202403":"已签到","202404":"已签到","202405":"未签到"}）；
	（2）函数内部完成以下操作：
	统计 “已签到” 的成员数量，返回该数值；
	提取所有 “未签到” 成员的学号，生成列表并返回；
	（3）调用该函数，传入示例签到字典{"202401":"已签到","202402":"未签到","202403":"已签到","202404":"已签到","202405":"未签到"}，并按格式输出结果：
	输出 “已签到人数：3”；
	输出 “未签到学号列表：['202402', '202405']”。
"""

def check_sign_in(sign_dict={}):
    sgc=0
    nsglist=[]
    for i in sign_dict:
        if sign_dict[i]=="已签到":
            sgc+=1
        else:
            nsglist.append(i)
    return sgc,nsglist

sgc,nsglist = check_sign_in({"202401":"已签到","202402":"未签到","202403":"已签到","202404":"已签到","202405":"未签到"})
print(f"已签到人数：{sgc}")
print(f"未签到学号列表：{nsglist}")
"""
8.文件操作
“天马来出月支窟，背为虎文龙翼骨。
嘶青云，振绿发，兰筋权奇走灭没。
腾昆仑，历西极，四足无一蹶。”
上述内容为李白的《天马歌》部分。请完成以下设计：
（1）定义文件file1.txt，将上述内容通过write的方式写入到文件中，要求按照本题的展示进行换行。
（2）定义一个新的文件file2.txt，新文件内容实现对file1.txt的拷贝。
"""

with open("file1.txt","w+") as file1, open("file2.txt","w+") as file2:
    file1.writelines(["天马来出月支窟，背为虎文龙翼骨。\n","嘶青云，振绿发，兰筋权奇走灭没。\n","腾昆仑，历西极，四足无一蹶。\n"])
    d = file1.readlines()
    file2.writelines(d)
"""
8.班级值日表初始内容如下：
	周一：张三
	周二：李四
	周三：王五
请编写 Python 程序完成以下文件操作：
	（1）以写入模式创建文件duty_list.txt，将上述初始值日表内容写入文件（保留换行）；
	（2）以追加模式打开duty_list.txt，添加周四、周五的值日信息：
		周四：赵六
		周五：孙七
	（3）以读取模式打开文件，读取所有内容，统计文件的总行数并输出（示例：“值日表总行数：5”）；
	（4）所有文件操作需正确关闭文件（使用close()方法）。

"""

f = open("duty_list.txt","w")
f.writelines(["周一：张三\n","周二：李四\n","周三：王五\n"])
f.close()
    
f = open("duty_list.txt","a")
f.writelines(["周四：赵六\n","周五：孙七\n"])
f.close()

f = open("duty_list.txt","r")
d = f.readlines()
print(f"值日表总行数：{len(d)}")
f.close()
"""
8.校园读书角需要整理推荐书单，书单内容如下：
	《Python编程：从入门到实践》
	《小王子》
	《平凡的世界》
	《解忧杂货店》
	《活着》
	请编写 Python 程序完成以下文件操作：
	（1）以写入模式打开（创建）文件book_list.txt，将上述书单内容逐行写入文件（每行一个书名，保留换行）；
	（2）以读取模式打开book_list.txt，逐行读取文件内容，打印每一行的书名（打印时去除换行符）；
	（3）所有文件操作需正确关闭文件（使用close()方法）。
"""

f = open("book_list.txt","w")
f.writelines(["《Python编程：从入门到实践》\n","《小王子》\n","《平凡的世界》\n","《解忧杂货店》\n","《活着》\n"])
f.close

f = open("book_list.txt","r")
d = f.readlines()
for i in range(len(d)):
    print(d[i].strip())
f.close
